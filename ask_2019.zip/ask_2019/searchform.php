<?php
/**
 * The template for displaying search forms.
 *
 * @file      searchform.php
 * @package   Ask CMS
 * @author    Abdullah Al Rajib.
 * @link 	  http://
 */
?>
 
<form method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
	<div>
		<input class="searchfield" type="text" value="<?php _e('Search', 'max-magazine');?>" name="s" id="ask_search" onfocus="if (this.value == 'Search') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search';}" />
	</div>
</form>
