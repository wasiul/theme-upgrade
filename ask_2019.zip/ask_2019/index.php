<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @file      index.php
 * @package   Ask CMS
 * @author    ASK Web.
 * @link 	  http://
 */
?> 
<?php get_header(); ?>


<?php 
// ASK Header Banner
if (is_home() && $paged < 2 ){
              echo'<div id="ask-header-banner" ></div>';
                                }
    ?>



<div id="content">		
	<h4 id="home-cat-title" class="cat-title"><a href="https://www.askbd.org/ask/category/press-statement/">Press Statement <span style="color:blue;">>>View all</span></a></h4>
		<?php
			//show on homepage only
			if (is_home() && $paged < 2 ){
               // echo'<div id="ask-header-banner" ></div>';
				//include slider
				if ( max_magazine_get_option( 'show_slider' ) == 1 ) {
					get_template_part('includes/slider'); 
				}
				
					//Print "<h4>To view Statistics, Please click 'Human Rights Monitoring'</h4>";
					
								//include carousel posts
				if ( max_magazine_get_option( 'show_carousel' ) == 1 ){
					get_template_part('includes/carousel'); 
				}
			
				if ( max_magazine_get_option( 'show_feat_cats' ) == 1) { ?>
					
					<div id="featured-categories">
			
					<?php
						
						//include featured category 1
						if ( max_magazine_get_option( 'feat_cat1' ) != 0) {
							get_template_part('includes/feat_cat1');			
						}
						
						//include featured category 2
						if ( max_magazine_get_option( 'feat_cat1' ) != 0) {
							get_template_part('includes/feat_cat2');			
						}
				
						//include featured category 3
						if ( max_magazine_get_option( 'feat_cat3' ) != 0) {
							get_template_part('includes/feat_cat3');			
						}
				
						//include featured category 4
						if ( max_magazine_get_option( 'feat_cat4' ) != 0) {
							get_template_part('includes/feat_cat4');			
						}
					?>
			
					</div> <!-- /featured-categories -->
	
					<h3 id="home-activities">What We Do</h3>
					<?php echo do_shortcode("[pt_view id=a46357d95s]"); ?>
	
					<h3 id="home-activities">ASK's Intervention</h3>
				<?php echo do_shortcode("[pt_view id=2928be7s9y]"); ?>
	<p><a href="https://www.askbd.org/ask/category/intervention/" target="_blank">More Intervention..</a></p>
	
			<?php 
				}
                
                
                
			} //is_home 
		
			//include latest posts
			if ( max_magazine_get_option( 'show_posts_list' ) != 0) {
				get_template_part('includes/content'); 				
			}
		
			//no option is set in the homepage, display posts list.
			if (( max_magazine_get_option( 'show_slider' ) == 0) and 
				( max_magazine_get_option( 'show_feat_cats' ) == 0) and 
				( max_magazine_get_option( 'show_carousel' ) == 0)){
			?>
				<div class="no-posts-notice">
					<?php _e('Please enable theme settings from the theme options', 'max-magazine'); ?>
				</div>
				<?php get_template_part('includes/content'); ?>
			
			<?php }	?>
	


</div><!-- /content -->

<?php get_sidebar(); ?>	
<?php get_footer(); ?>