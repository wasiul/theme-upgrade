<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content-container and the #container div.
 * Also contains the footer widget area.
 *
 * @file      footer.php
 * @package   Ask CMS
 * @author    Wasiul Alam Biswas
 * @link 	  http://
 */
 ?>
 
</div> <!-- /content-container -->
    <div id="footer">
        <div class="footer-widgets">
            
			<?php if ( ! dynamic_sidebar( 'sidebar-2' ) ) : ?>				
				
				<div class="widget widget_text" id="text-4">
					<h4>Lorem ipsum dolor sit amet</h4>
					<div class="textwidget">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</div>
				</div>
				
				<div class="widget">
					<h4><?php _e( 'Popular Categories', 'max-magazine' ); ?></h4>
					<ul><?php wp_list_categories( array( 'orderby' => 'count', 'order' => 'DESC', 'title_li' => '', 'number' => 5 ) ); ?></ul>
				</div>
				
				<?php the_widget('WP_Widget_Recent_Posts', 'number=5', 'before_title=<h4>&after_title=</h4>'); ?>
				<?php the_widget('WP_Widget_Recent_Comments', 'number=5', 'before_title=<h4>&after_title=</h4>'); ?> 
			
			<?php endif; // end footer widget area ?>		
			
		</div>
        
		<div class="footer-info">
            <p>	<?php /*?><a href="<?php echo home_url( '/' ); ?>" title="<?php bloginfo ('name');?>"><?php bloginfo ('name');?></a><?php */?> 
			Copyright © Ain o Salish Kendra (ASK), 2013-<?php echo date("Y"); ?>. All Rights Reserved.
            
            			
			</p>
			
			<div class="credit">
				<!-- Credit line should be here. -->
            </div>
        </div>        
	</div>

</div> <!-- /container -->
<?php wp_footer(); ?>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-103648158-1', 'auto');
  ga('send', 'pageview');
</script>

</body>
</html>